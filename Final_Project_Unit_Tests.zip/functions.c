#include "functions.h"
void push(int btn, int state, struct node **head)
{
	if (*head == NULL)
	{
		*head = malloc(sizeof(struct node));
		(*head)->btn = btn;
		(*head)->state = state;
		(*head)->next = NULL;
	}
	else
	{
		struct node *temp;
		temp = *head;
		while(temp->next != NULL)
		{
			temp = temp->next;
		}
		struct node * node;
		node = malloc(sizeof(struct node));
		node->btn = btn;
		node->state = state;
		node->next = NULL;
	}
}

void pop(int *btn, int *state, struct node **head)
{
	if (*head == NULL)
	{
		*btn = 2;
		*state = 2;
	}
	else
	{
		struct node *temp;
		temp = *head;
		*head = (*head)->next;
		*btn = temp->btn;
		*state = temp->state;
		free(temp);
	}
}

void physics_func(int gain, int Dir, int ed, int st, struct Physics *physics)
{
    //init
	
	physics->Gain = 0;
    physics->st = st;
    physics->ed = 0;
    physics->delta_t = 0;
    physics->Dir = 0;
    physics->gravity = 9.8;
    physics->mass = 20;
    physics->length = 0.5; //m
    physics->xmin = -64; //pixels
    physics->xmax = 64; //pixels
    physics->h_velocity = 0;
    physics->v_velocity = 0;
    physics->h_acceleration = 0;
    physics->v_acceleration = 0;
    physics->h_force = 0;
    physics->v_force = 0;
    physics->hb_force = 0;
    physics->vb_force = 0;
    physics->hc_force = 0;
    physics->vc_force = 0;
    physics->h_position = 0;
    physics->v_position = 0.5;
    physics->theta = 0;
	//func
	physics->ed = st;
	physics->delta_t = (physics->ed-physics->st)/1000;
	physics->vb_force = physics->mass * physics->gravity;
	physics->hb_force = physics->vb_force *tan(physics->theta);
	physics->hc_force = physics->Gain * (bool)(physics->Dir);
	physics->vc_force = physics->hc_force *tan(physics->theta);
	physics->v_force = physics->vc_force - physics->vb_force;
	if(physics->Dir == 1)
	{
		physics->h_force = physics->hb_force - physics->hc_force;
	}
	else if(physics->Dir == 2)
	{
		physics->h_force = physics->hc_force - physics->hb_force;
	}
	else
	{
		physics->h_force = physics->hb_force;
	}
	physics->v_acceleration = physics->v_force/physics->mass;
	physics->h_acceleration = physics->h_force/physics->mass;
	physics->v_velocity = physics->v_velocity + physics->v_acceleration*physics->delta_t;
	physics->h_velocity = physics->h_velocity + physics->h_acceleration*physics->delta_t;
	physics->v_position = physics->v_position + physics->v_velocity*physics->delta_t;
	physics->h_position = physics->h_position + physics->h_velocity*physics->delta_t;
	physics->theta = atan(physics->h_position/physics->v_position);
	physics->hc_position = physics->length*sin(physics->theta);

	physics->st = physics->ed;
}
