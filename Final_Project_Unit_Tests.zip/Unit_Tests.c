#include <stdlib.h>
#include "ctest.h"
#include "functions.h"
#include <stdio.h>

// Note: the name in the first parameter slot must match all tests in that group
CTEST_DATA(FIFO_Test) {
    struct node *head;
    int state;
    int btn;
};

CTEST_SETUP(FIFO_Test) {
    data->head = NULL;
    push(0,0,&(data->head));
}

CTEST2(FIFO_Test, test_process) {
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(0, data->btn);
    ASSERT_EQUAL(0, data->state);
}

CTEST_DATA(FIFO_Test1) {
    struct node *head;
    int state;
    int btn;
};

CTEST_SETUP(FIFO_Test1) {
    data->head = NULL;
}

CTEST2(FIFO_Test1, test_process1) {
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(2, data->btn);
    ASSERT_EQUAL(2, data->state);
}

CTEST_DATA(FIFO_Test2) {
    struct node *head;
    int state;
    int btn;
};

CTEST_SETUP(FIFO_Test2) {
    data->head = NULL;
    push(1,1,&(data->head));
}

CTEST2(FIFO_Test2, test_process2) {
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(1, data->btn);
    ASSERT_EQUAL(1, data->state);
}

CTEST_DATA(Physics_Test) {
    struct Physics physics;
    int gain;
    int Dir;
    int start;
    int end;
};

CTEST_SETUP(Physics_Test){
    data->physics.Gain = 0;
    data->physics.st = 0;
    data->physics.ed = 0;
    data->physics.delta_t = 0;
    data->physics.Dir = 0;
    data->physics.gravity = 9.8;
    data->physics.mass = 20;
    data->physics.length = 0.5;
    data->physics.xmin = -64;
    data->physics.xmax = 64;
    data->physics.h_velocity = 0;
    data->physics.v_velocity = 0;
    data->physics.h_acceleration = 0;
    data->physics.v_acceleration = 0;
    data->physics.h_force = 0;
    data->physics.v_force = 0;
    data->physics.hb_force = 0;
    data->physics.vb_force = 0;
    data->physics.hc_force = 0;
    data->physics.vc_force = 0;
    data->physics.h_position = 0;
    data->physics.v_position = 0.5;
    data->physics.theta = 0;
    data->gain = 0;
    data->Dir = 0;
    data->start = 0;
    data->end = 5; 
}

CTEST2(Physics_Test, test_process3) {
    
    physics_func(data->gain, data->Dir, data->end, data->start, &data->physics);
    ASSERT_EQUAL(0, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(.5, data->physics.v_position);
    ASSERT_EQUAL(0.005, data->physics.delta_t);
}

CTEST2(Physics_Test, test_process4) {
    data->gain = 1;
    data->Dir = 1;
    data->start = 0;
    data->end = 5;
    physics_func(data->gain, data->Dir, data->end, data->start, &data->physics);
    ASSERT_EQUAL(196, data->physics.vb_force);
    ASSERT_EQUAL(0, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(.5, data->physics.v_position);
    ASSERT_EQUAL(0.005, data->physics.delta_t);
}

CTEST2(Physics_Test, test_process5) {
    data->gain = 1;
    data->Dir = 1;
    data->start = 0;
    data->end = 5;
    physics_func(data->gain, data->Dir, data->end, data->start, &data->physics);
    ASSERT_EQUAL(196, data->physics.vb_force);
    ASSERT_EQUAL(0, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(.5, data->physics.v_position);
    ASSERT_EQUAL(0.005, data->physics.delta_t);
}

CTEST2(Physics_Test, test_process6) {
    data->gain = 1;
    data->Dir = 1;
    data->start = 0;
    data->end = 5;
    physics_func(data->gain, data->Dir, data->end, data->start, &data->physics);
    ASSERT_EQUAL(196, data->physics.vb_force);
    ASSERT_EQUAL(0, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(.5, data->physics.v_position);
    ASSERT_EQUAL(0.005, data->physics.delta_t);
}

CTEST2(Physics_Test, test_process7) {
    data->gain = 2;
    data->Dir = 1;
    data->start = 0;
    data->end = 10;
    physics_func(data->gain, data->Dir, data->end, data->start, &data->physics);
    ASSERT_EQUAL(196, data->physics.vb_force);
    ASSERT_EQUAL(0, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(.5, data->physics.v_position);
    ASSERT_EQUAL(0.01, data->physics.delta_t);
}

CTEST2(Physics_Test, test_process8) {
    data->gain = 5;
    data->Dir = -1;
    data->start = 0;
    data->end = 100;
    physics_func(data->gain, data->Dir, data->end, data->start, &data->physics);
    ASSERT_EQUAL(196, data->physics.vb_force);
    ASSERT_EQUAL(0, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(.5, data->physics.v_position);
    ASSERT_EQUAL(0.1, data->physics.delta_t);
}

CTEST2(Physics_Test, test_process9) {
    data->gain = 5;
    data->Dir = -1;
    data->start = 0;
    data->end = 1000;
    physics_func(data->gain, data->Dir, data->end, data->start, &data->physics);
    ASSERT_EQUAL(196, data->physics.vb_force);
    ASSERT_EQUAL(0, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(.5, data->physics.v_position);
    ASSERT_EQUAL(1, data->physics.delta_t);
}

