#include <stdbool.h>
struct node
{
	bool btn;
	bool state;
	struct node *next;
};

struct Physics
{
    int f;
    int v;
    int a;
    int xcart;
    int xball;
    int theta;
};


void pop(int *btn, int *state, struct node **head);

void push(int btn, int state, struct node **head);

void horizontal(int f, struct Physics physics);

