#include <stdio.h>
#include "functions.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
void push(int btn, int state, struct node **head)
{
	if (*head == NULL)
	{
		*head = malloc(sizeof(struct node));
		(*head)->btn = btn;
		(*head)->state = state;
		(*head)->next = NULL;
	}
	else
	{
		struct node *temp;
		temp = *head;
		while(temp->next != NULL)
		{
			temp = temp->next;
		}
		struct node * node;
		node = malloc(sizeof(struct node));
		node->btn = btn;
		node->state = state;
		node->next = NULL;
	}
}

void pop(int *btn, int *state, struct node **head)
{
	if (*head == NULL)
	{
		*btn = 2;
		*state = 2;
	}
	else
	{
		struct node *temp;
		temp = *head;
		*head = (*head)->next;
		*btn = temp->btn;
		*state = temp->state;
		free(temp);
	}
}

void horizontal(int f, struct Physics physics){
    physics.theta = 90;
    physics.a = 0;
    physics.v = 0;
    physics.f = f;
}
