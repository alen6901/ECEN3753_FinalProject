#include <stdlib.h>
#include "ctest.h"
#include "functions.h"
#include <stdio.h>

// Note: the name in the first parameter slot must match all tests in that group
CTEST_DATA(FIFO_Test) {
    struct node *head;
    int state;
    int btn;
};

CTEST_SETUP(FIFO_Test) {
    data->head = NULL;
    push(0,0,&(data->head));
}

CTEST2(FIFO_Test, test_process) {
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(0, data->btn);
    ASSERT_EQUAL(0, data->state);
}

CTEST_DATA(FIFO_Test1) {
    struct node *head;
    int state;
    int btn;
};

CTEST_SETUP(FIFO_Test1) {
    data->head = NULL;
}

CTEST2(FIFO_Test1, test_process1) {
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(2, data->btn);
    ASSERT_EQUAL(2, data->state);
}

CTEST_DATA(FIFO_Test2) {
    struct node *head;
    int state;
    int btn;
};

CTEST_SETUP(FIFO_Test2) {
    data->head = NULL;
    push(1,1,&(data->head));
}

CTEST2(FIFO_Test2, test_process2) {
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(1, data->btn);
    ASSERT_EQUAL(1, data->state);
}

CTEST_DATA(Physics_Test) {
    struct Physics physics;
    int f;
};

CTEST_SETUP(Physics_Test){
    data->f = 0; 
}

CTEST2(Physics_Test, test_process3) {
    data->f = 0;
    horizontal(data->f, data->physics);
    ASSERT_EQUAL(90, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.f);
}

CTEST2(Physics_Test, test_process4) {
    data->f = 1;
    horizontal(data->f, data->physics);
    ASSERT_EQUAL(89, data->physics.theta);
    ASSERT_EQUAL(1, data->physics.f);
}

CTEST2(Physics_Test, test_process5) {
    data->f = 2;
    horizontal(data->f, (data->physics));
    ASSERT_EQUAL(88, data->physics.theta);
    ASSERT_EQUAL(2, data->physics.a);
}

CTEST2(Physics_Test, test_process6) {
    data->f = 3;
    horizontal(data->f, (data->physics));
    ASSERT_EQUAL(86, data->physics.theta);
    ASSERT_EQUAL(3, data->physics.f);
}

CTEST2(Physics_Test, test_process7) {
    data->f = 4;
    horizontal(data->f, (data->physics));
    ASSERT_EQUAL(80, data->physics.theta);
    ASSERT_EQUAL(4, data->physics.f);
}

CTEST2(Physics_Test, test_process8) {
    data->f = 5;
    horizontal(data->f, (data->physics));
    ASSERT_EQUAL(76, data->physics.theta);
    ASSERT_EQUAL(5, data->physics.f);
}

CTEST2(Physics_Test, test_process9) {
    data->f = 10;
    horizontal(data->f, (data->physics));
    ASSERT_EQUAL(45, data->physics.theta);
    ASSERT_EQUAL(10, data->physics.f);
}

